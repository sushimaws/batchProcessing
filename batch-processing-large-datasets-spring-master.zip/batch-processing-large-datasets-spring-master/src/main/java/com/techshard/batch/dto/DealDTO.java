/**
 * 
 */
package com.techshard.batch.dto;

/**
 * @author sushim
 *
 */
public class DealDTO {
	
	private String indentifier;
	private String lv;
	private String currency;
	private String pl;
	private String date;
	
	private String date1;
	private String rate;
	private String amount1;
	private String amount2;
	private String ref;
	
	private String date3;
	private String extra1;
	private String extra2;
	private String extra3;
	private String extra4;
	/**
	 * @return the indentifier
	 */
	public String getIndentifier() {
		return indentifier;
	}
	/**
	 * @param indentifier the indentifier to set
	 */
	public void setIndentifier(String indentifier) {
		this.indentifier = indentifier;
	}
	/**
	 * @return the lv
	 */
	public String getLv() {
		return lv;
	}
	/**
	 * @param lv the lv to set
	 */
	public void setLv(String lv) {
		this.lv = lv;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the pl
	 */
	public String getPl() {
		return pl;
	}
	/**
	 * @param pl the pl to set
	 */
	public void setPl(String pl) {
		this.pl = pl;
	}
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the date1
	 */
	public String getDate1() {
		return date1;
	}
	/**
	 * @param date1 the date1 to set
	 */
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	/**
	 * @return the rate
	 */
	public String getRate() {
		return rate;
	}
	/**
	 * @param rate the rate to set
	 */
	public void setRate(String rate) {
		this.rate = rate;
	}
	/**
	 * @return the amlount1
	 */
	public String getAmount1() {
		return amount1;
	}
	/**
	 * @param amlount1 the amlount1 to set
	 */
	public void setAmount1(String amount1) {
		this.amount1 = amount1;
	}
	/**
	 * @return the amount2
	 */
	public String getAmount2() {
		return amount2;
	}
	/**
	 * @param amount2 the amount2 to set
	 */
	public void setAmount2(String amount2) {
		this.amount2 = amount2;
	}
	/**
	 * @return the ref
	 */
	public String getRef() {
		return ref;
	}
	/**
	 * @param ref the ref to set
	 */
	public void setRef(String ref) {
		this.ref = ref;
	}
	/**
	 * @return the date3
	 */
	public String getDate3() {
		return date3;
	}
	/**
	 * @param date3 the date3 to set
	 */
	public void setDate3(String date3) {
		this.date3 = date3;
	}
	/**
	 * @return the extra1
	 */
	public String getExtra1() {
		return extra1;
	}
	/**
	 * @param extra1 the extra1 to set
	 */
	public void setExtra1(String extra1) {
		this.extra1 = extra1;
	}
	/**
	 * @return the extra2
	 */
	public String getExtra2() {
		return extra2;
	}
	/**
	 * @param extra2 the extra2 to set
	 */
	public void setExtra2(String extra2) {
		this.extra2 = extra2;
	}
	/**
	 * @return the extra3
	 */
	public String getExtra3() {
		return extra3;
	}
	/**
	 * @param extra3 the extra3 to set
	 */
	public void setExtra3(String extra3) {
		this.extra3 = extra3;
	}
	/**
	 * @return the extra4
	 */
	public String getExtra4() {
		return extra4;
	}
	/**
	 * @param extra4 the extra4 to set
	 */
	public void setExtra4(String extra4) {
		this.extra4 = extra4;
	}

}
