/**
 * 
 */
package com.techshard.batch.configuration.processor;

import org.springframework.batch.item.ItemProcessor;

import com.techshard.batch.dto.DealDTO;

/**
 * @author sushim
 *
 */
public class DealProcessor implements ItemProcessor<DealDTO, DealDTO> {

	@Override
	public DealDTO process(DealDTO item) throws Exception {
		if (item.getIndentifier().equalsIgnoreCase("D")) {
			DealDTO retVal = new DealDTO();
			retVal.setCurrency(item.getCurrency().toUpperCase());
			retVal.setIndentifier(item.getIndentifier().toUpperCase());
			retVal.setDate(item.getDate().toUpperCase());
			retVal.setLv(item.getLv().toUpperCase());
			retVal.setPl(item.getPl().toUpperCase());
			retVal.setDate(item.getDate().toUpperCase());
			retVal.setDate1(item.getDate1().toUpperCase());
			retVal.setDate3(item.getDate3().toUpperCase());
			retVal.setRate(item.getRate().toUpperCase());
			retVal.setAmount1(item.getAmount1().toUpperCase());
			retVal.setAmount2(item.getAmount2().toUpperCase());
			retVal.setExtra1(item.getExtra1().toUpperCase());
			retVal.setExtra2(item.getExtra2().toUpperCase());
			retVal.setExtra3(item.getExtra3().toUpperCase());
			retVal.setExtra4(item.getExtra4().toUpperCase());
			retVal.setRef(item.getRef().toUpperCase());
			return retVal;
		}
		return null;
	}

}
