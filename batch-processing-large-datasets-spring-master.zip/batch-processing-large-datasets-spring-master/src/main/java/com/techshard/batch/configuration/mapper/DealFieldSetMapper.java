package com.techshard.batch.configuration.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;

import com.techshard.batch.dto.DealDTO;

@Component
public class DealFieldSetMapper implements FieldSetMapper<DealDTO> {

    @Override
    public DealDTO mapFieldSet(FieldSet fieldSet) {
        final DealDTO retVal = new DealDTO();

        retVal.setCurrency(fieldSet.readString("currency"));
		retVal.setIndentifier(fieldSet.readString("indentifier"));
		retVal.setDate(fieldSet.readString("date"));
		retVal.setLv(fieldSet.readString("lv"));
		retVal.setPl(fieldSet.readString("pl"));
		retVal.setDate(fieldSet.readString("date"));
		retVal.setDate1(fieldSet.readString("date1"));
		retVal.setDate3(fieldSet.readString("date3"));
		retVal.setRate(fieldSet.readString("rate"));
		retVal.setAmount1(fieldSet.readString("amount1"));
		retVal.setAmount2(fieldSet.readString("amount2"));
		retVal.setExtra1(fieldSet.readString("extra1"));
		retVal.setExtra2(fieldSet.readString("extra2"));
		retVal.setExtra3(fieldSet.readString("extra3"));
		retVal.setExtra4(fieldSet.readString("extra4"));
		retVal.setRef(fieldSet.readString("ref"));
        
        return retVal;

    }
}
