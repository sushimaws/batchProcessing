package com.techshard.batch.configuration;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.techshard.batch.configuration.mapper.DealFieldSetMapper;
import com.techshard.batch.configuration.processor.DealProcessor;
import com.techshard.batch.dto.DealDTO;
import com.techshard.batch.dto.HeaderDTO;
import com.techshard.batch.dto.TrailerDTO;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Bean
	public FlatFileItemReader<DealDTO> reader() {
		return new FlatFileItemReaderBuilder<DealDTO>().name("dealItemReader")
				.resource(new ClassPathResource("DEAL_SG_14102019_20112019_0333.txt")).delimited()

				.names(new String[] { "indentifier", "lv", "currency", "pl", "date", "date1", "rate", "amount1",
						"amount2", "ref", "date3", "extra1", "extra2", "extra3" })
				.lineMapper(lineMapper()).fieldSetMapper(new BeanWrapperFieldSetMapper<DealDTO>() {
					{
						setTargetType(DealDTO.class);
					}
				}).skippedLinesCallback(new LineCallbackHandler() {

					@Override
					public void handleLine(String line) {

						String[] headerSeparado = line.split("|");

						String identifier= headerSeparado[0];
						String source =  headerSeparado[1];;
						String country = headerSeparado[2];;
						String dateOrCount =  headerSeparado[3];;
						if(identifier=="HH") {
							HeaderDTO headerDTO = new HeaderDTO();
							headerDTO.setCountry(country);
							headerDTO.setIdentifier(identifier);
							headerDTO.setDate(dateOrCount);
							headerDTO.setSource(source);
						}else if(identifier=="ZZ") {
							TrailerDTO headerDTO = new TrailerDTO();
							headerDTO.setCountry(country);
							headerDTO.setIdentifier(identifier);
							headerDTO.setCount(dateOrCount);
							headerDTO.setSource(source);
						}

					}
				}).build();
	}

	@Bean
	public LineMapper<DealDTO> lineMapper() {

		final DefaultLineMapper<DealDTO> defaultLineMapper = new DefaultLineMapper<>();
		final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setDelimiter("|");
		lineTokenizer.setStrict(false);
		lineTokenizer.setNames(new String[] { "indentifier", "lv", "currency", "pl", "date", "date1", "rate", "amount1",
				"amount2", "ref", "date3", "extra1", "extra2", "extra3", "extra4" });

		final DealFieldSetMapper fieldSetMapper = new DealFieldSetMapper();
		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(fieldSetMapper);

		return defaultLineMapper;
	}

	@Bean
	public DealProcessor dealProcessor() {
		return new DealProcessor();
	}

	@Bean
	public Job importDealJob(NotificationListener listener, Step step1) {
	
		return jobBuilderFactory
				.get("importDealJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.start(step1)
				.build();
	}

	private Resource outputResource = new FileSystemResource("output/outputData.txt");

	@Bean
	public FlatFileItemWriter<DealDTO> dtoFileWriter() {
		FlatFileItemWriter<DealDTO> writer = new FlatFileItemWriter<>();
		writer.setResource(outputResource);
		writer.setAppendAllowed(true);
		writer.setLineAggregator(new DelimitedLineAggregator<DealDTO>() {
			{
				setDelimiter("|");
				setFieldExtractor(new BeanWrapperFieldExtractor<DealDTO>() {
					{
						setNames(new String[] { "indentifier", "lv", "currency", "pl", "date", "date1", "rate",
								"amount1", "amount2", "ref", "date3", "extra1", "extra2", "extra3", "extra4" });
					}
				});
			}
		});
		return writer;
	}

	@Bean
	public Step step1() {
		
		
		return stepBuilderFactory.
				get("step1").<DealDTO, DealDTO>chunk(10)
				.reader(reader())
				.processor(dealProcessor())
				.writer(dtoFileWriter()).build();
	}

}
